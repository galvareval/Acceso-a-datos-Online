/*
 * Acceso a Datos - Tarea UT6
 */
package com.ad06_tarea;

import java.util.ArrayList;
import org.xmldb.api.DatabaseManager;
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.Database;
import org.xmldb.api.base.XMLDBException;

/**
 *
 * @author Alba Tortosa
 */
public class AccesoDatos {

    private static final String driver = "org.exist.xmldb.DatabaseImpl";
    private static Collection col = null;

    //Obtiene una conexión a la base de datos
    public static void abrirConexion() {

        try {
            // initialize database driver
            Class cl = Class.forName(driver);
            Database database = (Database) cl.newInstance();
            DatabaseManager.registerDatabase(database);
            // get the collection
            col = DatabaseManager.getCollection("xmldb:exist://localhost:8081/exist/xmlrpc/db", "admin", "root");

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void cerrarConexion() {
        if (col != null) {
            try {
                col.close();
            } catch (XMLDBException xe) {
                xe.printStackTrace();
            }
        }
    }

    public static ArrayList<String> buscarMunicipios(String comunidad, String provincia) {
        ArrayList<String> municipios = new ArrayList();

        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Rellena la variable local "municipios" con la lista de todos los nombres de municipios de la base de datos
        //Muéstralos ordenados alfabéticamente
        //Utiliza una consulta que NO devuelva valores repetidos
        //Utiliza la libreria Xquery o XPath para realizar la búsqueda  
        
        
        //FIN
        return municipios;
    }

    public static String buscarProvincia(String municipio) {

        String provincia = null;
        
        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Rellena la variable local "provincia" con la provincia asociada al municipio pasado por parámetro
        //Utiliza una consulta que asegure que se obtiene un único resultado
        //Utiliza la libreria Xquery o XPath para realizar la búsqueda  
        
        
        //FIN
        return provincia;
    }

    public static ArrayList<String> buscarProvincias(String comunidad) {
        ArrayList<String> provincias = new ArrayList();

        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Rellena la variable local "provincias" con la lista de todos los nombres de provincias de la base de datos
        //Muéstralas ordenadas alfabéticamente
        //Utiliza una consulta que NO devuelva valores repetidos
        //Utiliza la libreria Xquery o XPath para realizar la búsqueda      
        
        
        //FIN
        return provincias;
    }

    public static String buscarComunidad(String provincia) {

        String comunidad = null;
        
        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Rellena la variable local "comunidad" con la comunidad asociada a la provincia pasada por parámetro
        //Utiliza una consulta que asegure que se obtiene un único resultado
        //Utiliza la libreria Xquery o XPath para realizar la búsqueda  

        
        //FIN
        return comunidad;
    }

    public static ArrayList<String> buscarComunidades() {
        ArrayList<String> comunidades = new ArrayList();

        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Rellena la variable local "comunidades" con la lista de todos los nombres de comunidades de la base de datos
        //Muéstralas ordenadas alfabéticamente
        //Utiliza una consulta que NO devuelva valores repetidos
        //Utiliza la libreria Xquery o XPath para realizar la búsqueda      
        
        
        //FIN
        return comunidades;
    }

    public static ArrayList<Playa> buscarPlayas(String comunidadSeleccionada, String provinciaSeleccionada, String municipioSeleccionado) {
        ArrayList<Playa> playas = new ArrayList();

        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Rellena la variable local "playas" con la lista de todas las playas que coincidan los filtros seleccionados
        //Muéstralas ordenadas alfabéticamente por nombre de playa
        //Utiliza la libreria Xquery o XPath para realizar la búsqueda   
        
        
        
        //FIN
        return playas;
    }

}
