/*
 * Acceso a Datos - Tarea UT4
 */
package com.mycompany.ad04_orm;

import com.mycompany.ad04_orm.persistencia.SessionFactoryUtil;
import com.mycompany.ad04_orm.persistencia.FilmCategoryId;
import com.mycompany.ad04_orm.persistencia.Film;
import com.mycompany.ad04_orm.persistencia.Language;
import com.mycompany.ad04_orm.persistencia.Category;
import com.mycompany.ad04_orm.persistencia.FilmCategory;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.exception.DataException;

/**
 *
 * @author Alba Tortosa
 */
public class AccesoDatos {

    public static ArrayList<Pelicula> buscarPeliculas(String titulo, String categoria, String calificacion) {

        ArrayList<Pelicula> peliculas = new ArrayList<Pelicula>();

        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Rellena la variable local "peliculas" con la lista de las peliculas que coincidan con los parámetros de entrada.
        //Tendrás que crear objetos de tipo Pelicula a partir de los objetos obtenidos de la base de datos (que serán de tipo Film)
        //Se pueden combinar las tres opciones de búsqueda. Si los tres paramétros se dejan vacíos, se mostrará la lista completa de películas.
        //En el caso del título, la coincidencia NO debe tener en cuenta las mayúsculas y minúsculas.
        //Utiliza una sentencia HQL
        //Cierra la conexion a base de datos al terminar
        // Consulta que une las tablas Film, FilmCategory y Category
        String hql = "SELECT f from Film f INNER JOIN f.filmCategories fc INNER JOIN fc.category c where ";
        //Añadimos el filtro de titulo
        hql += "lower(f.title) like lower('%" + titulo.trim() + "%')";
        //Añadimos el filtro de categoria
        if (!categoria.equals("")) {
            hql += " and c.name = '" + categoria + "'";
        }
        //Añadimos el filtro de rating
        if (!calificacion.equals("")) {
            hql += " and f.rating = '" + calificacion + "'";
        }
        //Ordenación
        hql += " order by title";

        //Crea la sesión global.
        SessionFactory sessionFactory = SessionFactoryUtil.getSessionFactory();
        Session s = sessionFactory.openSession(); //Abrimos la sesión   
        //Ejecutamos la consulta
        Query q = s.createQuery(hql);
        List resultList = q.list();
        //Creamos la lista de objetos Pelicula
        for (Object o : resultList) {
            Film film = (Film) o;
            Pelicula pelicula = new Pelicula();
            pelicula.setId(film.getFilmId());
            pelicula.setTitulo(film.getTitle());
            pelicula.setAnyo(film.getReleaseYear());
            pelicula.setDuracion(film.getLength());
            pelicula.setCalificacion(film.getRating());
            //La base de datos permite que una película tenga asociada más de una categoría, cogemos sólo la primera
            Iterator<FilmCategory> it = film.getFilmCategories().iterator();
            if (it.hasNext()) {
                pelicula.setCategoria(it.next().getCategory().getName());
            }
            //Buscamos el idioma
            Language language = film.getLanguageByLanguageId();
            pelicula.setIdioma(language.getName());

            peliculas.add(pelicula);
        }
        s.close();

        //FIN
        return peliculas;
    }

    public static ArrayList<String> buscarCategorias() {

        ArrayList<String> categorias = new ArrayList<String>();

        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Rellena la variable local "categorias" con la lista de todas las categorias de la base de datos
        //Utiliza una sentencia HQL
        //Cierra la sesión de la base de datos al terminar
        //Crea la sesión global.
        SessionFactory sessionFactory = SessionFactoryUtil.getSessionFactory();
        Session s = sessionFactory.openSession(); //Abrimos la sesión   
        //Consulta todas las categorías ordenadas alfabéticamente
        Query q = s.createQuery("from Category order by name");
        List resultList = q.list();
        //Creamos la lista de nombres de categorías
        for (Object o : resultList) {
            Category category = (Category) o;
            categorias.add(category.getName());
        }
        s.close();

        //FIN
        return categorias;
    }

    public static ArrayList<String> buscarCalificaciones() {

        ArrayList<String> calificaciones = new ArrayList<String>();

        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Rellena la variable local "calificaciones" con la lista de todas las calificaciones de la base de datos
        //Utiliza una sentencia HQL
        //Cierra la sesión de la base de datos al terminar
        //Crea la sesión global.
        SessionFactory sessionFactory = SessionFactoryUtil.getSessionFactory();
        Session s = sessionFactory.openSession(); //Abrimos la sesión   
        //Consulta todas las calificaciones ordenadas alfabéticamente
        Query q = s.createQuery("SELECT distinct rating from Film order by rating");
        List resultList = q.list();
        //Creamos la lista de calificaciones
        for (Object o : resultList) {
            String rating = (String) o;
            calificaciones.add(rating);
            Collections.sort(calificaciones);
        }
        s.close();
        //FIN
        return calificaciones;
    }

    public static ArrayList<String> buscarIdiomas() {

        ArrayList<String> idiomas = new ArrayList<String>();

        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Rellena la variable local "idiomas" con la lista de todas los idiomas de la base de datos
        //Utiliza una sentencia HQL
        //Cierra la sesión de la base de datos al terminar
        //Crea la sesión global.
        SessionFactory sessionFactory = SessionFactoryUtil.getSessionFactory();
        Session s = sessionFactory.openSession(); //Abrimos la sesión   
        //Consulta todos los idiomas ordenados alfabéticamente
        Query q = s.createQuery("from Language order by name");
        List resultList = q.list();
        //Creamos la lista de nombres de idiomas
        for (Object o : resultList) {
            Language language = (Language) o;
            idiomas.add(language.getName());
        }
        s.close();

        //FIN
        return idiomas;
    }

    public static String nuevaPelicula(String titulo, String anyo, String duracion, String calificacion, String idioma, String categoria) {
        String mensaje = "La película se ha creado correctamente";

        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Crea una nueva pelicula en la base de datos con los datos pasados por parámetro
        //Si ocurre cualquier otro error durante la ejecución, rellena la variable local "mensaje" con un mensaje relevante
        //Ten en cuenta que pueden llegar datos inválidos (longitud del titulo, textos en lugar de números...). Muestra errores apropiados en cada caso
        //Utiliza objetos persistentes
        //Cierra la conexion a base de datos al terminar
        //Crea la sesión global.
        SessionFactory sessionFactory = SessionFactoryUtil.getSessionFactory();
        Session s = sessionFactory.openSession(); //Abrimos la sesión 
        Transaction tx = null;
        try {
            tx = s.beginTransaction();
            Film film = new Film();

            //Rellenamos el titulo, año, duracion y calificacion. Eliminamos posibles espacios al comienzo y al final
            film.setTitle(titulo.trim());
            film.setReleaseYear(Short.valueOf(anyo.trim()));
            film.setLength(Short.valueOf(duracion.trim()));
            film.setRating(calificacion);

            //Buscamos el idioma en la base de datos y lo rellenamos
            Language language = (Language) s.createQuery("from Language where name = '" + idioma + "'").uniqueResult();
            film.setLanguageByLanguageId(language);

            //Guardamos la película y la volvemos a cargar para obtener su ID
            s.save(film);
            s.flush();
            s.refresh(film);

            //Buscamos la categoría en la base de datos y creamos un objeto FilmCategory
            Category category = (Category) s.createQuery("from Category where name = '" + categoria + "'").uniqueResult();
            FilmCategory filmCategory = new FilmCategory();
            filmCategory.setCategory(category);
            filmCategory.setFilm(film);
            FilmCategoryId filmCategoryId = new FilmCategoryId(film.getFilmId(), category.getCategoryId());
            filmCategory.setId(filmCategoryId);
            filmCategory.setLastUpdate(new Date());

            //Guardamos el objeto FilmCategory
            s.save(filmCategory);
            s.flush();

        } catch (Exception e) {
            e.printStackTrace();
            mensaje = "Ha ocurrido un error inesperado";
            if (e.getClass().equals(NumberFormatException.class)) {
                mensaje = "El año y la duración deben tener valores numéricos.";
            }
            if (e.getClass().equals(DataException.class)) {
                mensaje = "El título no debe contener más de 128 caracteres.";
            }

            if (tx != null) {
                tx.rollback();
            }
        } finally {
            s.close();
        }
        //FIN
        return mensaje;
    }

    public static String editarPelicula(String id, String titulo, String anyo, String duracion, String calificacion, String idioma, String categoria) {

        String mensaje = "La película se ha modificado correctamente";

        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Modifica la pelicula con el id proporcionado con los datos pasados por parámetro
        //Si ocurre cualquier otro error durante la ejecución, rellena la variable local "mensaje" con un mensaje relevante
        //Ten en cuenta que pueden llegar datos inválidos (longitud del titulo, textos en lugar de números...). Muestra errores apropiados en cada caso
        //Utiliza objetos persistentes
        //Cierra la conexion a base de datos al terminar
        //Crea la sesión global.
        SessionFactory sessionFactory = SessionFactoryUtil.getSessionFactory();
        Session s = sessionFactory.openSession(); //Abrimos la sesión 
        Transaction tx = null;
        try {
            tx = s.beginTransaction();
            Film film = (Film) s.load(Film.class, Short.valueOf(id));

            //Modificamos el titulo, año, duracion y calificacion sólo si han cambiado.  Eliminamos posibles espacios al comienzo y al final
            if (!film.getTitle().equals(titulo.trim())) {
                film.setTitle(titulo.trim());
            }
            if (!film.getReleaseYear().toString().equals(anyo)) {
                film.setReleaseYear(Short.valueOf(anyo.trim()));
            }
            if (!film.getLength().toString().equals(duracion.trim())) {
                film.setLength(Short.valueOf(duracion.trim()));
            }
            if (!film.getRating().equals(calificacion)) {
                film.setRating(calificacion);
            }

            //Modificamos el idioma sólo si ha cambiado
            if (!film.getLanguageByLanguageId().getName().equals(idioma)) {
                //Buscamos el idioma en la base de datos y lo rellenamos
                Language language = (Language) s.createQuery("from Language where name = '" + idioma + "'").uniqueResult();
                film.setLanguageByLanguageId(language);
            }

            //Guardamos la película
            s.save(film);
            s.flush();
            s.refresh(film);

            //Obtenemos la categoría asociada a la película
            Set filmCategories = film.getFilmCategories();
            Iterator<FilmCategory> it = filmCategories.iterator();
            FilmCategory filmCategory = new FilmCategory();
            if (it.hasNext()) {
                filmCategory = it.next();
            }
            //Modificamos la categoría sólo si ha cambiado
            if (!filmCategory.getCategory().getName().equals(categoria)) {
                //Buscamos la categoría en la base de datos y creamos un objeto FilmCategory
                Category category = (Category) s.createQuery("from Category where name = '" + categoria + "'").uniqueResult();
                //Borramos la categoría vieja
                s.delete(filmCategory);
                //Rellenamos la nueva categoría
                filmCategory.setCategory(category);
                filmCategory.setFilm(film);
                FilmCategoryId filmCategoryId = new FilmCategoryId(film.getFilmId(), category.getCategoryId());
                filmCategory.setId(filmCategoryId);
                filmCategory.setLastUpdate(new Date());

                //Guardamos el objeto FilmCategory
                s.save(filmCategory);
                s.flush();

            }

        } catch (Exception e) {
            e.printStackTrace();
            mensaje = "Ha ocurrido un error inesperado";
            if (e.getClass().equals(NumberFormatException.class)) {
                mensaje = "El año y la duración deben tener valores numéricos.";
            }
            if (e.getClass().equals(DataException.class)) {
                mensaje = "El título no debe contener más de 128 caracteres.";
            }

            if (tx != null) {
                tx.rollback();
            }
        } finally {
            s.close();
        }
        //FIN
        return mensaje;
    }

    public static String borrarPelicula(String id) {

        String mensaje = "La película se ha eliminado correctamente";

        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Elimina la pelicula con el id proporcionado
        //Si ocurre algún error durante la ejecución, rellena la variable local "mensaje" con un mensaje relevante
        //Utiliza objetos persistentes
        //Cierra la conexion a base de datos al terminar
        //Crea la sesión global.
        SessionFactory sessionFactory = SessionFactoryUtil.getSessionFactory();
        Session s = sessionFactory.openSession(); //Abrimos la sesión   
        Transaction tx = null;
        try {
            tx = s.beginTransaction();
            Film film = (Film) s.load(Film.class, Short.valueOf(id));
            s.delete(film);
            s.flush();

        } catch (Exception e) {
            e.printStackTrace();
            mensaje = "Ha ocurrido un error inesperado";
            if (tx != null) {
                tx.rollback();
            }
        } finally {
            s.close();
        }
        //FIN
        return mensaje;
    }

}
