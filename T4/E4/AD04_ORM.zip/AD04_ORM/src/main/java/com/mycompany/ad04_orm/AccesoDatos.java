/*
 * Acceso a Datos - Tarea UT4
 */
package com.mycompany.ad04_orm;

import java.util.ArrayList;

/**
 *
 * @author Alba Tortosa
 */
public class AccesoDatos {

    public static ArrayList<Pelicula> buscarPeliculas(String titulo, String categoria, String calificacion) {

        ArrayList<Pelicula> peliculas = new ArrayList<Pelicula>();

        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Rellena la variable local "peliculas" con la lista de las peliculas que coincidan con los parámetros de entrada.
        //Tendrás que crear objetos de tipo Pelicula a partir de los objetos obtenidos de la base de datos (que serán de tipo Film)
        //Se pueden combinar las tres opciones de búsqueda. Si los tres paramétros se dejan vacíos, se mostrará la lista completa de películas.
        //En el caso del título, la coincidencia NO debe tener en cuenta las mayúsculas y minúsculas.
        //Utiliza una sentencia HQL
        //Cierra la conexion a base de datos al terminar
        //FIN
        return peliculas;
    }

    public static ArrayList<String> buscarCategorias() {

        ArrayList<String> categorias = new ArrayList<String>();

        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Rellena la variable local "categorias" con la lista de todas las categorias de la base de datos
        //Utiliza una sentencia HQL
        //Cierra la sesión de la base de datos al terminar
        //FIN
        return categorias;
    }

    public static ArrayList<String> buscarCalificaciones() {

        ArrayList<String> calificaciones = new ArrayList<String>();

        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Rellena la variable local "calificaciones" con la lista de todas las calificaciones de la base de datos
        //Utiliza una sentencia HQL
        //Cierra la sesión de la base de datos al terminar
        //FIN
        return calificaciones;
    }

    public static ArrayList<String> buscarIdiomas() {

        ArrayList<String> idiomas = new ArrayList<String>();

        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Rellena la variable local "idiomas" con la lista de todas los idiomas de la base de datos
        //Utiliza una sentencia HQL
        //Cierra la sesión de la base de datos al terminar
        //FIN
        return idiomas;
    }

    public static String nuevaPelicula(String titulo, String anyo, String duracion, String calificacion, String idioma, String categoria) {
        String mensaje = "La película se ha creado correctamente";

        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Crea una nueva pelicula en la base de datos con los datos pasados por parámetro
        //Si ocurre cualquier otro error durante la ejecución, rellena la variable local "mensaje" con un mensaje relevante
        //Ten en cuenta que pueden llegar datos inválidos (longitud del titulo, textos en lugar de números...). Muestra errores apropiados en cada caso
        //Utiliza objetos persistentes
        //Cierra la conexion a base de datos al terminar
        //FIN
        return mensaje;
    }

    public static String editarPelicula(String id, String titulo, String anyo, String duracion, String calificacion, String idioma, String categoria) {

        String mensaje = "La película se ha modificado correctamente";

        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Modifica la pelicula con el id proporcionado con los datos pasados por parámetro
        //Si ocurre cualquier otro error durante la ejecución, rellena la variable local "mensaje" con un mensaje relevante
        //Ten en cuenta que pueden llegar datos inválidos (longitud del titulo, textos en lugar de números...). Muestra errores apropiados en cada caso
        //Utiliza objetos persistentes
        //Cierra la conexion a base de datos al terminar
        //FIN
        return mensaje;
    }

    public static String borrarPelicula(String id) {

        String mensaje = "La película se ha eliminado correctamente";

        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Elimina la pelicula con el id proporcionado
        //Si ocurre algún error durante la ejecución, rellena la variable local "mensaje" con un mensaje relevante
        //Utiliza objetos persistentes
        //Cierra la conexion a base de datos al terminar
        //FIN
        return mensaje;
    }

}
