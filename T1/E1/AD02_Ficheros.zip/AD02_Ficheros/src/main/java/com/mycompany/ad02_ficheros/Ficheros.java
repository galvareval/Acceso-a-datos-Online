/*
 * Acceso a Datos - Tarea UT2
 */
package com.mycompany.ad02_ficheros;

import java.io.File;
import java.util.ArrayList;

/**
 *
 * @author Alba Tortosa
 */
public class Ficheros {

    
    public static ArrayList<Fichero> buscarFicheros(String ruta) {
        
        ArrayList<Fichero> ficheros = new ArrayList<Fichero>();
        
        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Rellena la variable local "ficheros" con la lista de ficheros adecuada
        //Cada objeto fichero debe contener el nombre del fichero, el tipo (Fichero / Carpeta), el tamaño en Kilobytes y la última fecha de modificación
        
       
        
        //FIN
        return ficheros;
    }
    
    public static String exportarTxt(File fichero) {
        String mensaje = "La carpeta se ha creado correctamente";
        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Escribe en el fichero pasado por parámetro la lista de ficheros de la ruta seleccionada
        //Incluye las cabeceras de la tabla y utiliza tabuladores para que se mantenga el formato de tabla
        //Si ocurre algún error durante la ejecución, rellena la variable local "mensaje" con un mensaje relevante
        
        
        //FIN
        return mensaje;
    }
    
    public static String nuevaCarpeta(String ruta, String nombreCarpeta) {
        String mensaje = "La carpeta se ha creado correctamente";
        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Crea una carpeta en la ruta "ruta" pasada por parámetro y con el nombre "nombreCarpeta" pasado por parámetro
        //Si ya existe una carpeta con ese nombre en esa ruta, rellena la variable local "mensaje" con un mensaje relevante
        //Si ocurre algún error durante la ejecución, rellena la variable local "mensaje" con un mensaje relevante
        
        
        //FIN
        return mensaje;
    }
    
    public static String nuevoFichero(String ruta, String nombreFichero) {
        String mensaje = "El fichero se ha creado correctamente";
        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Crea un fichero en la ruta "ruta" pasada por parámetro y con el nombre "nombreFichero" pasado por parámetro
        //La extensión del fichero será TXT
        //Si ya existe un fichero con ese nombre en esa ruta, rellena la variable local "mensaje" con un mensaje relevante
        //Si ocurre algún error durante la ejecución, rellena la variable local "mensaje" con un mensaje relevante
        
        
        //FIN
        return mensaje;
    }
    
     public static String borrarFichero(String ruta, String nombreFichero) {
        String mensaje = "El fichero se ha borrado correctamente";
        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Borra el fichero pasado por parámetro de la ruta pasada por parámetro
        //Si el fichero no existe (o es un directorio), rellena la variable local "mensaje" con un mensaje relevante
        //Si ocurre algún error durante la ejecución, rellena la variable local "mensaje" con un mensaje relevante
        
        
        //FIN
        return mensaje;
    }
    
    
    
    public static String copiarFichero(String ruta, String fichero) {
        String mensaje = "El fichero se ha copiado correctamente";
        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Crea una copia del fichero pasado por parámetro en la ruta pasada por parámetro
        //El nombre del fichero debe ser el texto "Copia de " seguido del nombre original
        //Si ocurre algún error durante la ejecución, rellena la variable local "mensaje" con un mensaje relevante
        
        
        //FIN
        return mensaje;
    }
    
    

}
