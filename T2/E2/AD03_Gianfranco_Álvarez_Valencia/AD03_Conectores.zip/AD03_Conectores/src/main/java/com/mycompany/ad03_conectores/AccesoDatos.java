/*
 * Acceso a Datos - Tarea UT3
 */
package com.mycompany.ad03_conectores;

import java.sql.Connection;
import java.util.ArrayList;

/**
 *
 * @author Alba Tortosa
 */
public class AccesoDatos {
    
    private static String url = "jdbc:mysql://localhost:3306/aerolinea?serverTimezone=UTC";
    private static String user = "root";
    private static String password = "root";
    
    // Intenta obtener la conexión con la base de datos
    public static Connection getConnection() {
        Connection connection = null;
        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Establece una conexión con la base de datos utilizando las variables estáticas "url", "user" y "password"
        //Si ocurre cualquier otro error durante la ejecución, muestra el mensaje en el log de la aplicación
        
        
        //FIN
        return connection;
    }
    
    public static ArrayList<Vuelo> buscarVuelos() {
        
        ArrayList<Vuelo> vuelos = new ArrayList<Vuelo>();
        Connection con = getConnection();
        
        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Rellena la variable local "vuelos" con la lista de todos los vuelos de la base de datos
        //Cada objeto vuelo debe contener el codigo de vuelo, la fecha y hora, el origen y el destino
        //Cierra la conexion a base de datos al terminar
        
       
        
        //FIN
        return vuelos;
    }
    
    public static ArrayList<Pasajero> buscarPasajeros(String codigoVuelo) {
        
        ArrayList<Pasajero> pasajeros = new ArrayList<Pasajero>();
        Connection con = getConnection();
        
        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Rellena la variable local "pasajeros" con la lista de todos los pasajeros del vuelo pasado por parámetro
        //Cada objeto pasajero debe contener el dni, el tipo de plaza (Turista o Primera) y el asiento que ocupa
        //Cierra la conexion a base de datos al terminar
        
          
        //FIN
        return pasajeros;
    }
    
    
    public static String nuevoPasajero(String codigoVuelo, String dni, String tipoPlaza, String asiento) {
        
        String mensaje = "El pasajero se ha creado correctamente";
        Connection con = getConnection();
        
        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Crea un nuevo pasajero en la base de datos con los datos pasados por parámetro
        //Si ya existe un pasajero con el mismo DNI en el mismo vuelo, rellena la variable local "mensaje" con un mensaje relevante
        //Si el asiento seleccionado ya está ocupado en ese vuelo, rellena la variable local "mensaje" con un mensaje relevante
        //Si se ha superado el número máximo de plazas de turista y/o primera clase en el vuelo, rellena la variable local "mensaje" con un mensaje relevante
        //Si ocurre cualquier otro error durante la ejecución, rellena la variable local "mensaje" con un mensaje relevante
        //Cierra la conexion a base de datos al terminar
        
        
        //FIN
        return mensaje;
    }
    
    public static String cambiarAsiento(String codigoVuelo, String dni, String tipoPlaza, String asiento) {
        
        String mensaje = "El asiento se ha cambiado correctamente";
        Connection con = getConnection();
        
        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Permite cambiar el tipo y número de plaza de un pasajero en un vuelo.
        //Si el asiento seleccionado ya está ocupado en ese vuelo, rellena la variable local "mensaje" con un mensaje relevante
        //Si se ha superado el número máximo de plazas de turista y/o primera clase en el vuelo, rellena la variable local "mensaje" con un mensaje relevante
        //Si ocurre cualquier otro error durante la ejecución, rellena la variable local "mensaje" con un mensaje relevante
        //Cierra la conexion a base de datos al terminar
        
       
        //FIN
        return mensaje;
    }
    
    public static String borrarPasajero(String codigoVuelo, String dni) {
        
        String mensaje = "El pasajero se ha eliminado correctamente";
        Connection con = getConnection();
        
        //ESCRIBE AQUI TU CODIGO
        //INICIO
        //Elimina el pasajero seleccionado del vuelo seleccionado
        //Si ocurre algún error durante la ejecución, rellena la variable local "mensaje" con un mensaje relevante
        //Cierra la conexion a base de datos al terminar
        
        
        //FIN
        return mensaje;
    }
    
}
